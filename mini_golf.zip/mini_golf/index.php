<!DOCTYPE html>
<link rel="stylesheet" href="styles.css">
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Golf Reservation System</title>
</head>
<body>
    <h1>Welcome to the Mini Golf Reservation System</h1>
    <ul>
        <li><a href="addGolfer.php">Add Golfer</a></li>
        <li><a href="addReservation.php">Add Reservation</a></li>
        <li><a href="viewReservations.php">View Reservations</a></li>
    </ul>
</body>
</html>