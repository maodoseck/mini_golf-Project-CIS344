<?php
require_once 'MiniGolfDatabase.php';

$db = new MiniGolfDatabase();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['teeTimeId'])) {
    $teeTimeId = $_POST['teeTimeId'];

    // Delete reservation
    $db->query("DELETE FROM TeeTimes WHERE teeTimeId = ?", [$teeTimeId]);

    echo "Reservation deleted successfully! <a href='viewReservations.php'>Go back to Reservations</a>";
} else {
    echo "Invalid request. <a href='viewReservations.php'>Go back</a>";
}
?>