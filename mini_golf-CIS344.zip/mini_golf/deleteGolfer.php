<?php
require_once 'MiniGolfDatabase.php';

$db = new MiniGolfDatabase();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['golferId'])) {
    $golferId = $_POST['golferId'];

    // Delete golfer
    $db->query("DELETE FROM Golfers WHERE golferId = ?", [$golferId]);

    echo "Golfer deleted successfully! <a href='addGolfer.php'>Back to Manage Golfers</a>";
}
?>