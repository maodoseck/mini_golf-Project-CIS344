<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mini Golf Reservation System</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Additional styling for homepage */
        .homepage {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: linear-gradient(to bottom right, #00aaff, #0056b3);
            color: white;
            text-align: center;
        }

        .homepage h1 {
            font-size: 3rem;
            margin-bottom: 20px;
        }

        .homepage p {
            font-size: 1.2rem;
            margin-bottom: 30px;
        }

        .homepage .actions {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .homepage .actions a {
            display: block;
            background-color: white;
            color: #0056b3;
            text-decoration: none;
            padding: 15px 30px;
            font-size: 1.2rem;
            font-weight: bold;
            border-radius: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .homepage .actions a:hover {
            background-color: #0056b3;
            color: white;
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        }
    </style>
</head>
<body>
    <div class="homepage">
        <h1>Welcome to Mini Golf Reservation System</h1>
        <p>Manage your mini golf reservations seamlessly and efficiently. Choose an option below to get started.</p>
        <div class="actions">
            <a href="addGolfer.php">Add Golfer</a>
            <a href="addReservation.php">Add Reservation</a>
            <a href="viewReservations.php">View Reservations</a>
        </div>
    </div>
</body>
</html>